# Hello!

Thank you for trying Vincent van Git.

To paint to your Github contributions graph, run the `vincent-van-git.sh` file.

__Happy painting!__

-----

jh3y 2020 MIT

